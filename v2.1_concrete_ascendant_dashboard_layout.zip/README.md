
# v2.1 Concrete Ascendant

## Run

docker compose up --build

Frontend: http://localhost:3000
Backend Swagger: http://localhost:4000/api
